import torch
import torch.nn as nn
import torch.nn.functional as F


class Relu(nn.Module):
	def __init__(self):
		super(Relu,self).__init__()

	def forward(self, inputs):
		output = F.relu(inputs)
		return output

class conv_relu(nn.Module):
	def __init__(self, in_channels, out_channels, filter_size=3, stride=1, padding=1):
		super(conv_relu, self).__init__()
		self.conv = nn.Conv2d(in_channels, out_channels, filter_size, stride, padding)
		self.relu = Relu()

	def forward(self, inputs):
		output = self.conv(inputs)
		output = self.relu(output)
		return output


class CNNnet(nn.Module):
	def __init__(self, layers, in_channels, out_channels, kernel_size, stride=1, padding=1):
		super(CNNnet, self).__init__()
		self.layers = layers
		self.in_channels = in_channels
		self.out_channels = out_channels
		self.kernel_size = kernel_size
		for i in range(self.layers-1):
			setattr(self, 'conv_' + str(i+1), conv_relu(self.in_channels, 32, self.kernel_size))
			self.in_channels = 32
		setattr(self, 'conv_' + str(i+2), nn.Conv2d(self.in_channels,self.out_channels,self.kernel_size,1,1))

	def forward(self, inputs):
		x = inputs
		for i in range(self.layers):
			x = getattr(self, 'conv_' + str(i+1))(x)
		return x

# a = torch.ones(1,3,64,64)
# print(a.shape)
# net = CNNnet(5,3,1,3)
# b = net(a)
# print(b.shape)

