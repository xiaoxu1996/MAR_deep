import scipy.io
import torch
import numpy as np
#import mat4py


# load need Data
# mat_data_dict = scipy.io.loadmat('data/data.mat')
# for keys in mat_data_dict.keys():
# 	if str('__') not in keys:
# 		mat_data_keys = keys
# # # mat_data_keys = mat_data_dict.keys()
# # # print(mat_data_keys)
# mat_data = mat_data_dict[mat_data_keys]
# # data_names = mat_data[0,0].dtype.names
# # # for data_name in data_names:
# # # 	if str('data') in 
# # # index = mat_data[data_dtype[0]]
# # # print(data_dtype.shape)
# index = mat_data[0,0]['id']
# images = mat_data[0,0]['data']
# label = mat_data[0,0]['label']
# # 1 is training data ,2 is validation data 
# sets = mat_data[0,0]['set']

# for i in index[0]:
# 	j = sets[0][i-1]
# 	print(j)

def matdata_reader(filenames,batch_size,mode):
	def reader():
		mat_data_dict = scipy.io.loadmat(filenames)
		for keys in mat_data_dict.keys():
			if str('__') not in keys:
				mat_data_keys = keys
		mat_data = mat_data_dict[mat_data_keys]
		# get data
		indexs = mat_data[0,0]['id']
		images = mat_data[0,0]['data']
		label = mat_data[0,0]['label']
		# 1 is training data ,2 is validation data 
		setts = mat_data[0,0]['set']
		batch_out = []
		batch_out_label = []

		for index in indexs[0]:
			sett = setts[0][index-1]
			if mode == 'train' and sett == 1:
				img = images[:,:,:,index-1]
				lab = label[:,:,:,index-1]
			else:
				img = images[:,:,:,index-1]
				lab = label[:,:,:,index-1]
			img = np.array(img).astype('float32')
			lab = np.array(lab).astype('float32')
			img = img.transpose((2, 0, 1))
			lab = lab.transpose((2, 0, 1))
            # img = (img / 255.0 - 0.5) / 0.5
			batch_out.append(img)
			batch_out_label.append(lab)
			if len(batch_out) == batch_size:
				yield batch_out, batch_out_label
				batch_out = []
				batch_out_label = []
	return reader


# filenames = 'data/data.mat'
# train_reader = matdata_reader(filenames, batch_size=1, mode="train")
# for step in range(1, 11):
# 	try:
# 		A, B = next(train_iter)
# 		A = np.array(A)
# 		B = np.array(B)
# 	except:
# 		train_iter = iter(train_reader())
# 		A, B = next(train_iter)
# 		A = np.array(A)
# 		B = np.array(B)
# print(A.shape,B.shape)  
