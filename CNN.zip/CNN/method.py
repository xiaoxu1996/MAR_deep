import torch
import torch.nn as nn
import time
import os
#import cv2
import numpy as np
from glob import glob
from load_data import *
from load_model import CNNnet
import matplotlib.pyplot as plt
import imageio


class MAR_CNN(object):
	def __init__(self, args):
		self.args = args
		self.model_name = args.model_name
		if self.args.CUDA_FLAG:
			print('Start using cuda !')
			os.environ['CUDA_VISIBLE_DEVICES'] = '0'
			torch.backends.cudnn.enabled = True
			torch.backends.cudnn.benchmark = True
			self.dtype = torch.cuda.FloatTensor
		else:
			self.dtype = torch.FloatTensor

	def build_model(self):
		# load data
		self.train_data = matdata_reader(self.args.filenames, self.args.batch_size, mode="train")
		self.test_data = matdata_reader(self.args.filenames, self.args.batch_size, mode="test")
		# load networks
		self.network = CNNnet(self.args.layers, self.args.in_channels, self.args.out_channels, self.args.kernel_size).type(self.dtype)
		# define loss
		self.L2_loss = nn.MSELoss().type(self.dtype)
		# define optim
		self.optim = torch.optim.SGD(self.network.parameters(),lr=self.args.lr)

	def train(self):
		self.network.train()
		start_iter = 1
		print('training start !')

		#start_time = time.time()
		plot_x = []
		plot_loss_train = []
		plot_loss_val = []
		epochs = 1
		for step in range(start_iter, self.args.iteration + 1):
			try:
				data_img, data_lab = next(train_iter)
			except:
				train_iter = iter(self.train_data())
				data_img, data_lab = next(train_iter)
			data_img = torch.from_numpy(np.array(data_img)).type(self.dtype)
			data_lab = torch.from_numpy(np.array(data_lab)).type(self.dtype)
			# print(data_img.shape)
			self.optim.zero_grad()
			net_img = self.network(data_img)
			net_train_loss = self.L2_loss(data_lab, net_img)
			net_train_loss.backward()
			self.optim.step()
			print("[%5d/%5d] train_loss: %.8f" % (step,self.args.iteration, net_train_loss))
			#next_time = time.time()
			if step % self.args.val_freq == 0:
				#test_sample_num = 5
				self.network.eval()
				#for _ in range(test_sample_num):
				try:
					val_img, val_lab = next(test_iter)
				except:
					test_iter = iter(self.train_data())
					val_img, val_lab = next(test_iter)
				val_img = torch.from_numpy(np.array(val_img)).type(self.dtype)
				val_lab = torch.from_numpy(np.array(val_lab)).type(self.dtype)
				out_img = self.network(val_img)
				net_val_loss = self.L2_loss(val_lab, out_img)
				print("[%5d/%5d] val_loss: %.8f" % (step,self.args.iteration, net_val_loss))
				#out_img = out_imgs[0].detach().cpu().numpy().transpose(1,2,0)
				# out_img = (out_img - np.min(out_img)) / (np.max(out_img) - np.min(out_img))
				# plt.imshow(out_img)
				# plt.show()
				# cv2.imwrite(os.path.join(self.args.result_dir, self.model_name, 'img', '_%05d.png' % step), out_img)
			self.network.train()
			if step % self.args.loss_freq == 0:
				plot_x.append(epochs)
				plot_loss_train.append(net_train_loss)
				plot_loss_val.append(net_val_loss)
				epochs = epochs + 1
			if epochs % self.args.save_freq == 0:
				self.save(os.path.join(self.args.result_dir, self.model_name, 'model'), epochs)

			if epochs % 2000 == 0:
				params = {}
				params['network'] = self.network.state_dict()
				torch.save(params, os.path.join(self.args.result_dir, self.model_name, '_params_latest.pt'))
		plt.title('objective')
		plt.plot(plot_x, plot_loss_train, color='blue', label='train')
		plt.plot(plot_x, plot_loss_val, color='orange', label='val')
		plt.legend()
		plt.xlabel('training epoch')
		plt.ylabel('energy')
		plt.show()
	def save(self, dir, step):
		params = {}
		params['network'] = self.network.state_dict()
		torch.save(params, os.path.join(dir, self.model_name + '_params_%05d.pt' % step))

	def load(self, dir, step):
		params = torch.load(os.path.join(dir, self.model_name + '_params_%05d.pt' % step))
		self.network.load_state_dict(params['network'])

	def test(self):
		model_list = glob(os.path.join(self.args.result_dir, self.model_name, 'model', '*.pt'))
		if not len(model_list) == 0:
			model_list.sort()
			iter = int(model_list[-1].split('_')[-1].split('.')[0])
			self.load(os.path.join(self.args.result_dir, self.model_name, 'model'), iter)
			print(" [*] load success !")
		else:
			print(" [*] load failure !")
			return

		self.network.eval()
		for n, (test_img, _) in enumerate(self.test_data()):
			test_img = test_img.type(self.dtype)
			outputs = self.network(test_img)
			output = outputs[0].detach().cpu().numpy().transpose(1,2,0)
			cv2.imwrite(os.path.join(self.args.result_dir, self.model_name, 'test', '_%d.png' % (n+1)), output * 255)

torch.cuda.empty_cache()