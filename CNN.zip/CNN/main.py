import argparse
import os
from method import MAR_CNN

def str2bool(x):
	return x.lower() in ('true')

def parse_args():
	desc = 'pytorch implementation of Deep Learning in MAR'
	parse = argparse.ArgumentParser(description=desc)
	parse.add_argument('--phase', type=str, default='train', help='[train / test]')
	parse.add_argument('--model_name', type=str, default='CNN', choices=['CNN','FCNs','Unet'])
	parse.add_argument('--filenames', type=str, default='data/data.mat', help='The root of the datasets')
	parse.add_argument('--CUDA_FLAG', type=str2bool, default=True)
	parse.add_argument('--device', type=str, default='cpu', choices=['cpu','cuda'])
	parse.add_argument('--result_dir', type=str, default='result', help='Directory name to save the results')
	# CNN configuration
	parse.add_argument('--batch_size', type=int, default=16, help='The size of batch size')
	parse.add_argument('--layers', type=int, default=5, help='The numbers of conv layers')
	parse.add_argument('--in_channels', type=int, default=3, help='The channels of input data')
	parse.add_argument('--out_channels', type=int, default=1, help='The channels of output data')
	parse.add_argument('--kernel_size', type=int, default=3, help='The size of kernel')
	parse.add_argument('--lr', type=float, default=0.02, help='The learning rates')
	parse.add_argument('--iteration', type=int, default=16000, help='The number of training iterations')
	parse.add_argument('--save_freq', type=int, default=1000, help='The number of model save freq')
	parse.add_argument('--loss_freq', type=int, default=8, help='The number of model loss freq')
	parse.add_argument('--val_freq', type=int, default=7, help='The number of model val loss freq')
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()
	# parse.add_argument()

	return check_args(parse.parse_args())

def check_folder(log_dir):
	if not os.path.exists(log_dir):
		os.makedirs(log_dir)
	return log_dir

def check_args(args):
	check_folder(os.path.join(args.result_dir, args.model_name, 'model'))
	check_folder(os.path.join(args.result_dir, args.model_name, 'img'))
	check_folder(os.path.join(args.result_dir, args.model_name, 'test'))
	return args

def main():
	# parse arguments
	args = parse_args()
	if args is None:
		exit()
	# open session
	net = MAR_CNN(args)
	# build graph
	net.build_model()
	if args.phase == 'train' :
		net.train()
		print(" [*] Training finished!")
	if args.phase == 'test' :
		net.test()
		print(" [*] Test finished!")

if __name__ == '__main__':
	main()